"""Utils module initialization."""
